#!/bin/bash

cd "$(dirname "$0")"

chmod 644 sshd_config
chmod 600 services.chargers.enovates.eco.pub
cp sshd_config services.chargers.enovates.eco.pub /etc/ssh/

/etc/init.d/sshd restart
