#!/bin/bash

CONFIG_FILE="/etc/ssh/sshd_config"

# Backup the original config
cp "$CONFIG_FILE" "${CONFIG_FILE}.bak.$(date +%F_%T)"

# Enable password authentication
if grep -q "^#PasswordAuthentication" "$CONFIG_FILE"; then
    sed -i 's/^#PasswordAuthentication.*/PasswordAuthentication yes/' "$CONFIG_FILE"
elif grep -q "^PasswordAuthentication" "$CONFIG_FILE"; then
    sed -i 's/^PasswordAuthentication.*/PasswordAuthentication yes/' "$CONFIG_FILE"
else
    echo "PasswordAuthentication yes" >> "$CONFIG_FILE"
fi

/etc/init.d/sshd restart
